import pygame

from pygame.sprite import Sprite


class Ship(Sprite):

    def __init__(self, ai_game):
        super().__init__()
        self.screen = ai_game.screen
        self.settings = ai_game.settings
        self.screen_rect = ai_game.screen.get_rect()
        self.timer = 0

        self.explodeSequence = [pygame.image.load('images/explosion1.bmp'),
                              pygame.image.load('images/explosion2.bmp'),
                              pygame.image.load('images/explosion3.bmp'),
                              pygame.image.load('images/explosion4.bmp'),
                              pygame.image.load('images/explosion5.bmp'),
                              pygame.image.load('images/explosion6.bmp'),
                              pygame.image.load('images/explosion7.bmp'),
                              pygame.image.load('images/explosion8.bmp'),
                              pygame.image.load('images/explosion9.bmp'),
                              pygame.image.load('images/explosion10.bmp'),
                              pygame.image.load('images/explosion11.bmp'),
                              pygame.image.load('images/explosion12.bmp')]

        self.image = pygame.image.load('images/ship.bmp')
        self.rect = self.image.get_rect()

        self.rect.midbottom = self.screen_rect.midbottom

        self.x = float(self.rect.x)

        self.moving_right = False
        self.moving_left = False

    def explode(self):
        for deathFrame in len(self.explodeSequence):
            if self.timer >= 5:
                self.image = self.explodeSequence[deathFrame]
                self.timer = 0
            else:
                self.timer += 1

    def update(self):
        if self.moving_right and self.rect.right < self.screen_rect.right:
            self.x += self.settings.ship_speed
        if self.moving_left and self.rect.left > 0:
            self.x -= self.settings.ship_speed

        self.rect.x = self.x

    def blitme(self):
        self.screen.blit(self.image, self.rect)

    def center_ship(self):
        self.rect.midbottom = self.screen_rect.midbottom
        self.x = float(self.rect.x)
