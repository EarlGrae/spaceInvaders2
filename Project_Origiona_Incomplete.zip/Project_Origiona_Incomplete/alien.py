import pygame
from pygame.sprite import Sprite


class Alien(Sprite):

    def __init__(self, ai_game, enemyType):
        super().__init__()
        self.screen = ai_game.screen
        self.settings = ai_game.settings

        self.type = enemyType
        self.imagesType1 = [pygame.image.load('images/enemyType1Stage1.bmp'),
                            pygame.image.load('images/enemyType1Stage2.bmp')]
        self.imagesType2 = [pygame.image.load('images/enemyType2Stage1.bmp'),
                            pygame.image.load('images/enemyType2Stage2.bmp')]
        self.imagesType3 = [pygame.image.load('images/enemyType3Stage1.bmp'),
                            pygame.image.load('images/enemyType3Stage2.bmp')]
        self.deathImage =   pygame.image.load('images/enemyExplosion.bmp')
        self.index = 0
        self.isAlive = True
        self.timer = 0
        if self.type == 1:
            self.image = self.imagesType1[self.index]
        if self.type == 2:
            self.image = self.imagesType2[self.index]
        if self.type == 3:
            self.image = self.imagesType3[self.index]
        self.rect = self.image.get_rect()

        self.rect.x = self.rect.width
        self.rect.y = self.rect.height

        self.x = float(self.rect.x)

    def check_edges(self):
        screen_rect = self.screen.get_rect()
        if self.rect.right >= screen_rect.right or self.rect.left <= 0:
            return True

    def getPoint(self):
        if self.type == 1:
            return 10
        if self.type == 2:
            return 20
        if self.type == 3:
            return 40

    def explode(self):
        self.isAlive = False
        self.timer = 0


    def update(self):
        if self.isAlive:
            self.x += (self.settings.alien_speed *
                       self.settings.fleet_direction)
            self.rect.x = self.x
            if self.timer >= 50:
                self.timer = 0
                self.index += 1
                if self.index >= len(self.imagesType1): #all aliens have same sprite number, any list can be chosen interchangibly
                    self.index = 0
                if self.type == 1:
                    self.image = self.imagesType1[self.index]
                if self.type == 2:
                    self.image = self.imagesType2[self.index]
                if self.type == 3:
                    self.image = self.imagesType3[self.index]
            else:
                self.timer += 1
        else:
            self.image = self.deathImage
            if self.timer > 15:
                self.kill()
            else:
                self.timer += 1
