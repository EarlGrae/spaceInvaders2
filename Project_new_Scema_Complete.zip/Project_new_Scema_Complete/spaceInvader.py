
from pygame import *
from pygame.sprite import Sprite
import sys
from os.path import abspath, dirname
from random import choice

""" 
creates path templates to each folder for use in dictionary creation of pygame img/txt/wav files
i used the os library briefly in my software engineering class, learning how this line worked greatly reinforced 
that knowlege
to begin, __file__ and __path. although __file__ is not used, it is prerequisite in understanding path. __file__ acts
simmilarly to a preprocessor macro in c++, becoming the name of a module loaded in python. __path__ will become a
path-ish object for the modules. you will typically see it used in import, but this is another nice use for it 
dirname(path) returns the parent directory of (path). clears up the __path__ object into something more useable,
although it is not a clear path yet 
abspath() will normalize path. very simmilar in useage to normpath(). will convert the __path__ to a windows-recognised
file path.
"""
BASE_PATH = abspath(dirname(__file__))
# interesting note, doing it this way(creating the whole path) will require a /images/ instead of a /image.
# this is because instead of beginning in the root file, the abspath() will result in the whole path from the user
# this is immensely useful in real life dev istead of any other form, as it will allow the game or .py file to be run
# OUTSIDE of pycharm local repos if an exe is made
FONT_PATH = BASE_PATH + '/fonts/'
IMAGE_PATH = BASE_PATH + '/images/'
SOUND_PATH = BASE_PATH + '/sounds/'

# Colors (R, G, B)
# define the colors to be used, just like in the book
WHITE = (255, 255, 255)
GREEN = (78, 255, 87)
YELLOW = (241, 255, 0)
BLUE = (80, 255, 239)
PURPLE = (203, 0, 255)
RED = (237, 28, 36)

# unlike the other project template, this uses a smaller set size. i perfer this over the fullscreen, as
# pygame.FULLSCREEN is pretty finicky and using a set size alows for greater control
SCREEN = display.set_mode((800, 600))
# this font is used for most of the text drawing. as the only font, no dictionary is made
FONT = FONT_PATH + 'space_invaders.ttf'
# a list containing keys which will both allow for the creation of the dictionary, as well as serve as easy object
# recovery when an object needs to be pulled. each name(key) is the corresponding file name without it's .png extention
IMG_NAMES = ['ship', 'mystery',
             'enemy1_1', 'enemy1_2',
             'enemy2_1', 'enemy2_2',
             'enemy3_1', 'enemy3_2',
             'explosionblue', 'explosiongreen', 'explosionpurple',
             'laser', 'enemylaser']

# using the corresponding key set up in IMG_NAMES, a pygame object is made and assigned to each object.
IMAGES = {name: image.load(IMAGE_PATH + '{}.png'.format(name)).convert_alpha()
          for name in IMG_NAMES}
"""
This will be my explination for the above line, as i believe it is something VERY useful in not just game dev, but 
python development as a whole. when i was first modifying the old files, i was getting constantly bogged down making
pygame.image.load objects. pygame was imported *, meaning pygame.image.load can be shortened to image.load
then the creation of the acuaul objects. using the imagepath, which was created using the abspath(dirname(__path__)) + 
'/images', this path to the image file is concatenated with the specific key's image name. this is done using the 
.format() method, in which the {} is replaced with the format parameter. lastly, the convert_alpha pygame method is used
this will create a new method of the surface which is IDEAL for bliting to the actual surface which will be used. in
other words, it will change the pixel format of the origional image so nothing looks out of place. when i first was
attempting this project using the other template, i did not use conver_alpha and solved this problem by creating all my
.bmp images in photoshop to be the exact same size. this assists in fixing issues like this
finally, i was unaware of this form of for loop usage previously. it runs the dictionary creation the amount of times
each key in the key list. after running this, IMAGES will be a dictionary containing a key-object pair for each image
"""

# basic globals used much like the settings.py file
BLOCKERS_POSITION = 450
ENEMY_DEFAULT_POSITION = 65  # Initial value for a new game
ENEMY_MOVE_DOWN = 35

# whenever i saw a module member used, such as sprite, it always had much of its path included. eg sprite.Sprite as
# opposed to just Sprite. I'm assuming this to be a reasonable person standard, much like using std:: as a namespace
# instead of using namespace std; at the top in c++. i opted out of doing this for this project, but may do so in the
# future


class Ship(Sprite):
    def __init__(self):
        Sprite.__init__(self)
        # using the IMAGES dictionary, the image can be easilly objained using the ship key. sorry to harp on, I just
        # really like this idea
        self.image = IMAGES['ship']
        self.rect = self.image.get_rect(topleft=(375, 540))
        # the pygame getrect method creates a new rect on the surface the size of the image which called it. in this
        # case, the size of the ship image. the rect is then placed at (x, y). however, using the topleft= we can set
        # the topleft corner, and since we know the size of the screen (again why i said this has much better control)
        # we can get a definite positioning of the ship.
        self.speed = 5
        # just like in the settings of the other project, the speed the ship will go. used as the mathematical operator

    def update(self, keys, *args):
        if keys[K_LEFT] and self.rect.x > 10:
            self.rect.x -= self.speed
        if keys[K_RIGHT] and self.rect.x < 740:
            self.rect.x += self.speed
        game.screen.blit(self.image, self.rect)
        # see other proj for how i got this. basic movement of the ship


class Bullet(Sprite):
    # basic constructor. allows for only one bullet class which can vary rather than two classes, 1 alien and 1 player
    def __init__(self, xpos, ypos, direction, speed, filename, side):
        Sprite.__init__(self)
        self.image = IMAGES[filename]
        self.rect = self.image.get_rect(topleft=(xpos, ypos))
        self.speed = speed
        self.direction = direction
        self.side = side
        self.filename = filename

    def update(self, keys, *args):
        game.screen.blit(self.image, self.rect)
        self.rect.y += self.speed * self.direction
        if self.rect.y < 15 or self.rect.y > 600:
            self.kill()
        # using the self.kill() method is infinately easier to control that the groupcollide deletion. also,
        # knowing bounds for the window is much easier to control than fullscreen math. no prerequisites say that
        # the game HAS to be fullscreen, so i chose to do it the easier way


class Enemy(Sprite):
    """
    a few explinations. in the previous attempt, i struggled in trying to figure out how to make only the front enemies
    shoot, as that's how it works in the actual game. the enemies created as a fleet had no idea if they were the
    one in the front, they actually had no idea who their neighbors were at all. I previously was just going to let
    any enemy shoot randomly, and enemy bullets would have no collision function with aliens. this was only because of
    how the classes were written though, it wasnt easy to fix without drastically changing everything. once i used a
    different template though, i used the column and row self variables to fix this problem. if an enemy has the largest
     column value in the grid, it is clear to shoot. everything else here i believe is self-explaitory, either that has
     been shown in class or explained above
    """

    def __init__(self, row, column):
        Sprite.__init__(self)
        self.row = row
        self.column = column
        self.images = []
        self.load_images()
        self.index = 0
        self.image = self.images[self.index]
        self.rect = self.image.get_rect()

    def toggle_image(self):
        self.index += 1
        if self.index >= len(self.images):
            self.index = 0
        self.image = self.images[self.index]
        # this is a basic sprite loop. i used the same method in getting the sprites to cycle in the previous attempt

    def update(self, *args):
        game.screen.blit(self.image, self.rect)

    def load_images(self):
        images = {0: ['1_2', '1_1'],
                  1: ['2_2', '2_1'],
                  2: ['2_2', '2_1'],
                  3: ['3_1', '3_2'],
                  4: ['3_1', '3_2'],
                  }
        """
         this was another really cool idea of how to create one class with mult alien types. it's very simmilar to how
         i made it work in the previous attempt, but more pythonic. I previously made 3 lists, each with two different
         images, then also gave the alien class a self.type value. depending on the type, a different list would be used
         when creating the fleet, three loops were used. one for enemy type 1, one for type 2, one for type 3
         this would create that 3 different space invaders loop, but took an unnecicarry amount of work. here, we define
         the alien layout inside the enemy class. row 0 is type 1, the next 2 rows are type 2, and the final 2 are type 
         3. the list "images" records what row gets what image. using format, the correct image type is appended to 
         enemy to get the correct images dependant on that enemy's row. EG, row 0 gets images enemy1_2 and enemy 1_1.
         the images are then transformed to fit and are appended to the enemy's images tab, where they will be cycled 
         through using the same index method i used previously.
         
         im not sure this is more efficient, as every time an enemy is generated it creates this list, however it is
         much nicer to me than creating a series of if statements in the update function which get run though each time.
         it's also much more consice, making it easier to work with and understand    
        """
        img1, img2 = (IMAGES['enemy{}'.format(img_num)] for img_num in
                      images[self.row])
        self.images.append(transform.scale(img1, (40, 35)))
        self.images.append(transform.scale(img2, (40, 35)))
        # note: transform.scale resizes resolution to match (width, height). again, this is why i opted for a
        # non-fullscreen resolution, knowing a good res makes these kinds of transformations much simpler and neater


class EnemiesGroup(sprite.Group):
    # im unsure why i need to include the pygame.sprite.Group path here, as i imported Sprite. but it gets angry at me
    # if i dont, so here it stays
    def __init__(self, columns, rows):
        sprite.Group.__init__(self)
        # im subclassing sprite in this class, so i have to use the above line before i can acually add sprites to this
        # group. Note that this isnt inheriting anything unlike the other class in the previous template. i dont need
        # any enemy values or objects, so i dont need to use the super() method
        self.enemies = [[None] * columns for _ in range(rows)]
        # total number of enemies initially in the grid will be rows * columns
        self.columns = columns
        self.rows = rows
        # enemy movement is timer based, not position based. the usage of these variables is best explained in update.
        # doing it this way lets the infamous enemy speed up as there are fewer be done easier
        self.leftAddMove = 0
        self.rightAddMove = 0
        # the additional amount of moves the block needs as the block gets smaller
        self.moveTime = 600
        self.direction = 1
        # direction variable. think pong project. 1 is right, -1 is left
        self.rightMoves = 30
        self.leftMoves = 30
        # the amount each moves at it's base, when all enemies are still there
        self.moveNumber = 15
        self.timer = time.get_ticks()
        # this pygame method returns the time in ms since pygame.init() was called. used to control updates
        self.bottom = game.enemyPosition + ((rows - 1) * 45) + 35
        # game is the spaceInvaders object. .enemyposition will be defaulted to the value set at the top global settings
        # this line sets up the bottom positions of the enemy block(grid). bottom of the bottommost enemy
        # 45 is the y px length of an enemy, bo gap between top of screen and top of enemy block (game.enemyposition)
        # + # of rows*length of each row + enemy jump = bottom of block from top of screen
        self._aliveColumns = list(range(columns))
        # creates a list containing the number of columns made, using range to populate the list columns times
        self._leftAliveColumn = 0
        self._rightAliveColumn = columns - 1

    def update(self, current_time):
        # selftimer updates at the end of each update cycle. this makes movement occur every > movetime miliseconds
        if current_time - self.timer > self.moveTime:
            if self.direction == 1:
                max_move = self.rightMoves + self.rightAddMove
                # the amount of moves(speed)the alien will move. this is the upper bound number in a directional move
            else:
                max_move = self.leftMoves + self.leftAddMove

            # this compares the bound movement with the current move. if they match (should never be higher, but good
            # practice), then the direction will flip and the block moves down ENEMY_MOVE_DOWN pixels
            if self.moveNumber >= max_move:
                self.leftMoves = 30 + self.rightAddMove
                self.rightMoves = 30 + self.leftAddMove # finds out if more moves are now needed
                self.direction *= -1 # flips enemy direction
                self.moveNumber = 0
                self.bottom = 0
                # moveNumber goes to 0 because the direction is changed, and so the block is now 0 moves in that
                # direction. bottom needs to get reset based upon the moveDownAmount and the bottom alien's y
                for enemy in self:
                    enemy.rect.y += ENEMY_MOVE_DOWN # moves all enemies down
                    enemy.toggle_image() # cycles the enemy's sprites
                    if self.bottom < enemy.rect.y + 35:
                        self.bottom = enemy.rect.y + 35
            else:
                velocity = 10 if self.direction == 1 else -10 # if not moving down, move left or right depending on
                for enemy in self:                            # direction. pretty straightforward. move rects, image cyc
                    enemy.rect.x += velocity
                    enemy.toggle_image()
                self.moveNumber += 1 # 1 move closer to the wall (max_moves)

            self.timer += self.moveTime

    # this is not my function. however, understanding how it worked led to my understanding of sprite manipulation.
    # basically, after hours of research, group freaks out if you try to add a non-sprite to it. letting EnemiesGroup
    # inherit from sprite allows for freer use of the enemiesGroup group. for each s enemy in the enemyGroup, enemies
    # is modified. it's a simple overload of the add_internal function of the group class, which is what allows for the
    # adding of sprites to groups. This is essentially a modification of the group constructor if you will. well,
    # #add_internal is closer to append(). however, append can only accept certain inputs, other inputs have to have
    # append() overloaded or modified to allow those inputs in. this acts exactly in that way
    def add_internal(self, *sprites):
        super(EnemiesGroup, self).add_internal(*sprites)
        for s in sprites:
            self.enemies[s.row][s.column] = s

    # a manipulation of the remove_internal group function. this function is responsible for removing sprites within a
    # group. this manipulation will remove the elements the above add_internal mod allowed group to add to groups.
    # essentially modifies the group deconstructor(ish) to also remove elements it would not know exited otherwise.
    # Note that neither add_internal or remove_internal are functions created by me. they are fundamentals of the group
    # class in pygame/sprite, and I am simply adding a few lines to allow me to have the versitility i need
    def remove_internal(self, *sprites):
        super(EnemiesGroup, self).remove_internal(*sprites)
        for s in sprites:
            self.kill(s)
        self.update_speed()

    def is_column_dead(self, column): # checks a given row to see if there are any survivors left. true if none left
        return not any(self.enemies[row][column]
                       for row in range(self.rows))

    def random_bottom(self): # returns a random enemy in the bottommost position
        col = choice(self._aliveColumns) # uses random's choice function to get a random column
        col_enemies = (self.enemies[row - 1][col]
                       for row in range(self.rows, 0, -1)) # selects the enemy which is bottommost in the column
        return next((en for en in col_enemies if en is not None), None) # works from top down looking for a not none val
        # for syntax: returns the first value of en which is a not none enemy, or the next uses the default none
        # note that next will return the first value of the iteration if need be

        # speeds up the game. remember that movetime is the variable which limits an enemy movement.
        # when there are 10 or less enemies, the aliens move every 400 seconds. When there is
        # one left, the enemies go from moving every 400 ms to every 200 ms. creates a much more hectic game. lower
        # the number to get a more crazy moving ship. 200 and 50's pretty fun, and is closest to the origional
        # i think i'll change it to that. i might also make each level progressively faster, although i dont think that
        # is how the origional works. if i do, ill make a level multiplier parameter that divides with the base
    def update_speed(self):
        if len(self) == 1:
            self.moveTime = 50
        elif len(self) <= 10:
            self.moveTime = 200

        # kills an enemy inside the group object. the entire group isnt being deleted (see remove_internal), just one
        # alien. however that alien death requires confirmations such as is a row gone (should it speed up), is a
        # column gone (do more moves have to be made?) etc
    def kill(self, enemy):
        self.enemies[enemy.row][enemy.column] = None # wipe the enemy list(grid)
        is_column_dead = self.is_column_dead(enemy.column) # function created above to run through a row and ret true if
                                                           # there are no enemies left
        if is_column_dead:
            self._aliveColumns.remove(enemy.column) # removes the dead column from the list generated in the constructor

        if enemy.column == self._rightAliveColumn: # if the rightmost column is gone, more moves will be needed to cross
                                                   # the screen
            while self._rightAliveColumn > 0 and is_column_dead: # imagine there are only two columns alive, seperated
                self._rightAliveColumn -= 1                      # by 3 empty columns. this checks for this case and
                self.rightAddMove += 5                           # defines the correct rightmost column and values
                is_column_dead = self.is_column_dead(self._rightAliveColumn)

        elif enemy.column == self._leftAliveColumn: # same as above, but for the left empty column
            while self._leftAliveColumn < self.columns and is_column_dead:
                self._leftAliveColumn += 1
                self.leftAddMove += 5
                is_column_dead = self.is_column_dead(self._leftAliveColumn)


class Blocker(Sprite):
    def __init__(self, size, color, row, column):
        Sprite.__init__(self)
        self.height = size
        self.width = size
        self.color = color
        self.image = Surface((self.width, self.height))
        self.image.fill(self.color)
        self.rect = self.image.get_rect()
        self.row = row
        self.column = column
        # these are all methods i covered earlier. pretty straightforward construction

    """
    now this one's interesting. the update fuction i just overloaded here actually does literally nothing origionally.
    that's right, sprite.update, although existing, is written to do nothing, and only exists so that it can be override
    it's a pretty simple override, just updates it's image when called to new paramaters
    """
    def update(self, keys, *args):
        game.screen.blit(self.image, self.rect)

    #the UFO class. piggybacking on some enemy code here
class Mystery(Sprite):
    def __init__(self):
        Sprite.__init__(self)
        self.image = IMAGES['mystery']
        self.image = transform.scale(self.image, (75, 35))
        self.rect = self.image.get_rect(topleft=(-80, 45))
        self.row = 5
        self.moveTime = 25000
        self.direction = 1
        self.timer = time.get_ticks()
        self.mysteryEntered = mixer.Sound(SOUND_PATH + 'mysteryentered.wav')
        self.mysteryEntered.set_volume(0.3)
        self.playSound = True
        # this flag tells the update its ok to start playing the sound

    """
    overrideing the update again, but has more depth to it this time than just redoing the img. 
    """
    def update(self, keys, currentTime, *args): # im not sure i mentioned it above, but it was not covered so i'll show
                                                # my knowlege so you know im not using it willy-nilly. the *args is
                                                # unpacking args to use it's contents as paramaters
        resetTimer = False # timer before the ufo CAN appear again. wont be on if the ufo is on screen
        passed = currentTime - self.timer
        if passed > self.moveTime: # the ufo doesnt move with the other aliens. it has it's own speed. this
            if (self.rect.x < 0 or self.rect.x > 800) and self.playSound: # moniters that movement
                self.mysteryEntered.play() # if it is on the screen, play the ocilations. only triggers once
                self.playSound = False
            if self.rect.x < 840 and self.direction == 1: # if it is on the screen on the left and moving right
                self.mysteryEntered.fadeout(4000) # fade out the sound over 4 seconds (the time approx it should take)
                self.rect.x += 2 # move it to the right at 2 pixels / moveTime
                game.screen.blit(self.image, self.rect)
            if self.rect.x > -100 and self.direction == -1: # same as above, but handleing left movement
                self.mysteryEntered.fadeout(4000)
                self.rect.x -= 2
                game.screen.blit(self.image, self.rect)

        if self.rect.x > 830: # if the ufo spawns off the right, move left
            self.playSound = True
            self.direction = -1
            resetTimer = True
        if self.rect.x < -90: # if the ufo spawns in the left, move right
            self.playSound = True
            self.direction = 1
            resetTimer = True
        if passed > self.moveTime and resetTimer: # update the timer
            self.timer = currentTime



"""
this was interestingly enough why i started looking for functions that led to me using this kind of format/template
opposed to the other one. i did get it working there, but it was so clunky in that format i started looking for a better
way of doing it. i did things here pretty much the same way i did it there, stop the old sprite cycle, start the 
explosion, wait a bit, then delete the alien. only difference here is that in the old version, i included the 
explosion sprite in the alien class and had the explosion be part of the update class whcih was goverened by a bool
flag called isDead  
"""
class EnemyExplosion(Sprite):
    def __init__(self, enemy, *groups):
        super(EnemyExplosion, self).__init__(*groups) # set up the images and rects about to be used
        self.image = transform.scale(self.get_image(enemy.row), (40, 35)) # get the image, set it's pixels to fit the
        self.image2 = transform.scale(self.get_image(enemy.row), (50, 45)) # enemy rect so nothings wonky
        self.rect = self.image.get_rect(topleft=(enemy.rect.x, enemy.rect.y)) # generate explosion's rect
        self.timer = time.get_ticks() # set up a timer for this obj. same as any class

    @staticmethod
    # in case you were wondering why this is static, i dont need the cls or the self at all. i dont use any
    # enemyExplosion variables, and really i could have had this list at the top with the image dictionary. thing is,
    # the explosion list is only used inside this class, so it makes clarity sense to have it stored/made here
    def get_image(row):
        img_colors = ['purple', 'blue', 'blue', 'green', 'green']
        return IMAGES['explosion{}'.format(img_colors[row])]

    def update(self, current_time, *args):
        passed = current_time - self.timer # sounter for the boom
        if passed <= 100:
            game.screen.blit(self.image, self.rect) # stage 1 of the explosion
        elif passed <= 200:
            game.screen.blit(self.image2, (self.rect.x - 6, self.rect.y - 6)) # stage 2 of the explosion shrinks a bit
        elif 400 < passed:
            self.kill() # explosion is over, get rid of that ship
        # this is almost identical to how i did explosions last time, although having it in it's own class gives one
        # HUGE difference. namely, explosions WONT stop player bullets, unlike in the other variation. it's so minor and
        # fast the average player wont notice, but it is nevertheless a detail a good game should consider

# handles the points and text display if the ufo is shot
class MysteryExplosion(Sprite):
    def __init__(self, mystery, score, *groups):
        super(MysteryExplosion, self).__init__(*groups) # inherits from all the groups(*groups = unpacked passed groups)
        self.text = Text(FONT, 20, str(score), WHITE, # contains white font 20 x 6 pixels of the already generated
                         mystery.rect.x + 20, mystery.rect.y + 6) #ufo point amount
        self.timer = time.get_ticks()

    # draws the generated text on the screen where the ufo was for 2 seconds then deletes the text
    def update(self, current_time, *args):
        passed = current_time - self.timer
        if passed <= 200 or 400 < passed <= 600:
            self.text.draw(game.screen)
        elif 600 < passed:
            self.kill()


class ShipExplosion(Sprite):
    def __init__(self, ship, *groups):
        super(ShipExplosion, self).__init__(*groups) # inherits from all passed sprite groups - all the sprites in those
        explosion_names = ['1', '2', '3', '4', '5',
                           '6', '7', '8', '9', '10',
                           '11', '12', '13', '14', '15',
                           '16']
        self.image = {name: image.load(IMAGE_PATH + 'explosion{}.png'.format(name)).convert_alpha()
                       for name in explosion_names}
        self.rect = self.image['1'].get_rect(topleft=(ship.rect.x, ship.rect.y)) # gets the old ship's x&y for the new rect
        self.timer = time.get_ticks()

    def update(self, current_time, *args): # kills the ship, but gives time for the animation
        passed = current_time - self.timer # plays the 16 frame death explosion, one frame each 15 ms
        if 300 < passed <= 600: # i wanted the ship to just flash in and out 8 times, but figured you wanted an actual
            if passed < 318: # animation so i whipped it up in photoshop. try replacing this mess with a 1 pic blit to
                game.screen.blit(self.image['1'], self.rect) # see how it looked!
            if passed >= 318 and passed < 336:
                game.screen.blit(self.image['2'], self.rect)
            if passed >= 336 and passed < 354:
                game.screen.blit(self.image['3'], self.rect)
            if passed >= 354 and passed < 372:
                game.screen.blit(self.image['4'], self.rect)
            if passed >= 372 and passed < 390:
                game.screen.blit(self.image['5'], self.rect)
            if passed >= 390 and passed < 408:
                game.screen.blit(self.image['6'], self.rect)
            if passed >= 408 and passed < 426:
                game.screen.blit(self.image['7'], self.rect)
            if passed >= 426 and passed < 444:
                game.screen.blit(self.image['8'], self.rect)
            if passed >= 444 and passed < 462:
                game.screen.blit(self.image['9'], self.rect)
            if passed >= 462 and passed < 480:
                game.screen.blit(self.image['10'], self.rect)
            if passed >= 480 and passed < 498:
                game.screen.blit(self.image['11'], self.rect)
            if passed >= 498 and passed < 516:
                game.screen.blit(self.image['12'], self.rect)
            if passed >= 516 and passed < 534:
                game.screen.blit(self.image['13'], self.rect)
            if passed >= 534 and passed < 552:
                game.screen.blit(self.image['14'], self.rect)
            if passed >= 570 and passed < 588:
                game.screen.blit(self.image['15'], self.rect)
            if passed >= 600:
                game.screen.blit(self.image['16'], self.rect)
        elif 900 < passed:
            self.kill() # kills the old ship


class Life(Sprite):
    def __init__(self, xpos, ypos):
        Sprite.__init__(self) # subclassing sprite, needs this
        self.image = IMAGES['ship'] # create a clone of that image
        self.image = transform.scale(self.image, (23, 23)) # shrink the ship image clone
        self.rect = self.image.get_rect(topleft=(xpos, ypos)) # put the clone image in the give x,y

    def update(self, *args): # deletes a life if need be
        game.screen.blit(self.image, self.rect)


class Text(object):
    def __init__(self, textFont, size, message, color, xpos, ypos):
        self.font = font.Font(textFont, size)
        self.surface = self.font.render(message, True, color)
        # font.render draws text on a surface. it is anti-aliased in this case
        self.rect = self.surface.get_rect(topleft=(xpos, ypos))
        # creates the rect to put the text on the size of the created text and puts it in a given x,y position

    def draw(self, surface):
        surface.blit(self.surface, self.rect)
        #pretty simple, the components are already builts. blit's the text onto the premade rect


class SpaceInvaders(object):
    # the mamaclass for the game. where the magic happens
    def __init__(self):
        mixer.pre_init(44100, -16, 1, 4096)
        # presets the mixer, im using pretty much the presets from pygame.org.
        # standard 44100 hz frequency, size is -16? i dont actually know what this preset means. but it's what the
        # website which made the function recommends
        # the rest i do. only need one channel, and the standard 512 buffersize was making errors its bumped to 4096
        init()
        # this initializes pygame. now, this is actually really important, for one main reason. every timer i used is
        # counting the ms from when pygame was initalized. so this line marks the start of every counter
        self.clock = time.Clock()
        #dont get confused with the time library's clock function. i did. this creates a pygame clock to help track time
        self.caption = display.set_caption('Space Invaders') # basic values to be used in the game's running. title here
        self.screen = SCREEN
        self.background = image.load(IMAGE_PATH + 'background.jpg').convert() # changes the pic to fit resolutionwise
        self.startGame = False                                                #sets bg
        self.mainScreen = True
        self.gameOver = False # these flags track where you are in the game
        # this value will get lower as rounds go on, giving the player less and less time each subsequent round.
        # chose this over speeding up enemies
        self.enemyPosition = ENEMY_DEFAULT_POSITION
        self.titleText = Text(FONT, 50, 'Space Invaders', WHITE, 164, 155)
        self.titleText2 = Text(FONT, 25, 'Press any key to continue', WHITE,
                               201, 225)
        self.gameOverText = Text(FONT, 50, 'Game Over', WHITE, 250, 270)
        self.nextRoundText = Text(FONT, 50, 'Next Round', WHITE, 240, 270)
        self.enemy1Text = Text(FONT, 25, '   =   10 pts', GREEN, 368, 270)
        self.enemy2Text = Text(FONT, 25, '   =  20 pts', BLUE, 368, 320)
        self.enemy3Text = Text(FONT, 25, '   =  40 pts', PURPLE, 368, 370)
        self.enemy4Text = Text(FONT, 25, '   =  ?????', RED, 368, 420) # Makes all the text surfaces that will be used
        self.scoreText = Text(FONT, 20, 'Score', WHITE, 5, 5)
        self.livesText = Text(FONT, 20, 'Lives ', WHITE, 640, 5)

        self.life1 = Life(715, 3) # positioning the lives so they look all perty
        self.life2 = Life(742, 3) # AGAIN, this is why i perfer to know my screen resolution. this would be hell if i
        self.life3 = Life(769, 3) # had to try to figure this out mathwise.
        self.livesGroup = sprite.Group(self.life1, self.life2, self.life3) # group the life sprites

    def reset(self, score): # i wont be explaining this in too much detail. resets everything back to the base for a new
        self.player = Ship() # game. can also be used for initial group and value initializations
        self.playerGroup = sprite.Group(self.player)
        self.explosionsGroup = sprite.Group()
        self.bullets = sprite.Group()
        self.mysteryShip = Mystery()
        self.mysteryGroup = sprite.Group(self.mysteryShip)
        self.enemyBullets = sprite.Group()
        self.make_enemies()
        self.allSprites = sprite.Group(self.player, self.enemies,
                                       self.livesGroup, self.mysteryShip)
        self.keys = key.get_pressed()
        # this gets the state of all keyboard buttons. the returned list holds true for the one(s) pressed

        self.timer = time.get_ticks()
        self.noteTimer = time.get_ticks()
        self.shipTimer = time.get_ticks()
        self.score = score
        self.create_audio()
        self.makeNewShip = False
        self.shipAlive = True

    # generates a single clocker pixel at row, column
    def generate_blocker(self, number, row, column, blockerGroup):
        blocker = Blocker(10, GREEN, row, column)
        blocker.rect.x = 50 + (200 * number) + (column * blocker.width)
        blocker.rect.y = BLOCKERS_POSITION + (row * blocker.height)
        blockerGroup.add(blocker)

    def make_blockers(self, number): # forms blocker sprites into a shield shape
        blockerGroup = sprite.Group()
        for row in range(6):
            for column in range(9):
                if row == 5:
                    if column not in range(2, 7):
                        self.generate_blocker(number, row, column, blockerGroup)
                if row == 4:
                    if column not in range(3, 6):
                        self.generate_blocker(number, row, column, blockerGroup)
                if row in range(2, 4):
                    self.generate_blocker(number, row, column, blockerGroup)
                if row == 1:
                    if column in range(2, 7):
                        self.generate_blocker(number, row, column, blockerGroup)
                if row == 0:
                    if column in range(3, 6):
                        self.generate_blocker(number, row, column, blockerGroup)
        return blockerGroup

    #generates all audio and sets up the mixer
    def create_audio(self):
        self.sounds = {}
        for sound_name in ['shoot', 'shoot2', 'invaderkilled', 'mysterykilled',
                           'shipexplosion']:
            self.sounds[sound_name] = mixer.Sound(
                SOUND_PATH + '{}.wav'.format(sound_name)) # same method we have been using to make the dictionaries
            self.sounds[sound_name].set_volume(0.2)       # lowers the sound. it can get loud

# the space invaders theme is just 4 notes looped. the musicNotes list contains those, and i will cycle through them
        # as if they were sprites in a sprite list. as a bonus, this lets me speed up these notes as the game speeds up
        # by having a note play if an enemy moves, which will make the game more exciting and hectic as they speed up

        self.musicNotes = [mixer.Sound(SOUND_PATH + '{}.wav'.format(i)) for i
                           in range(4)]
        for sound in self.musicNotes:
            sound.set_volume(0.5) # it's the game's main audio track, better make it louder

        self.noteIndex = 0 # which note are we on

    def play_main_music(self, currentTime):
        if currentTime - self.noteTimer > self.enemies.moveTime: # runs every time the enemies move. make a little
            self.note = self.musicNotes[self.noteIndex]  # load the note we want to play            # marching tune
            if self.noteIndex < 3: #cycle the notes, just like we would a sprite
                self.noteIndex += 1
            else:
                self.noteIndex = 0

            self.note.play()
            self.noteTimer += self.enemies.moveTime # add to the timer so we dont lose time anywhere

    @staticmethod
    # it makes sense to put a quit methon in the main class, but it doesnt need self. that's why it's static
    def should_exit(evt):
        return evt.type == QUIT or (evt.type == KEYUP and evt.key == K_ESCAPE) # escape closes the game, not q

    def check_input(self):
        self.keys = key.get_pressed() # mentioned above, get_pressed returns a list of all keys true if pressed
        for e in event.get():
            if self.should_exit(e): # event handler that quits on esc
                sys.exit()
            if e.type == KEYDOWN: # branch to handle shooting. pretty much from the book w/ a few simple mods
                if e.key == K_SPACE:
                    if len(self.bullets) == 0 and self.shipAlive: # SA prevents ship from firing when dead
                        if self.score < 1000: # a fun little twist. the player gets two shots after 1000 points
                            bullet = Bullet(self.player.rect.x + 23,
                                            self.player.rect.y + 5, -1,
                                            15, 'laser', 'center') # see bullet constructor
                            self.bullets.add(bullet) # throw it in the bullet group
                            self.allSprites.add(self.bullets)
                            self.sounds['shoot'].play()
                        else:
                            leftbullet = Bullet(self.player.rect.x + 8,
                                                self.player.rect.y + 5, -1,
                                                15, 'laser', 'left')
                            rightbullet = Bullet(self.player.rect.x + 38,
                                                 self.player.rect.y + 5, -1,
                                                 15, 'laser', 'right')
                            self.bullets.add(leftbullet)
                            self.bullets.add(rightbullet)
                            self.allSprites.add(self.bullets)
                            self.sounds['shoot2'].play()

    def make_enemies(self):
        enemies = EnemiesGroup(10, 5) # creates an enemy group with 10 columns and 5 rows of aliens
        for row in range(5):
            for column in range(10):
                enemy = Enemy(row, column) # populates the eneny group with an enemy object
                enemy.rect.x = 157 + (column * 50) # creates the enemy rect x. not the alien rect, the draw rect for the
                enemy.rect.y = self.enemyPosition + (row * 45)# creates the enemy y value              #block of enemies
                enemies.add(enemy) # push the created enemy into the enemies group

        self.enemies = enemies # stores the enemy group inside the main game class

    def make_enemies_shoot(self): # handles alien firing
        if (time.get_ticks() - self.timer) > 700 and self.enemies: # if there are aliens left and timer is met
            enemy = self.enemies.random_bottom() # choose an enemy at the bottom of a random column
            self.enemyBullets.add(
                Bullet(enemy.rect.x + 14, enemy.rect.y + 20, 1, 5,
                       'enemylaser', 'center')) # make the bullet and add it to the enemybullet group
            self.allSprites.add(self.enemyBullets) # add the bullet to the game's central sprite group
            self.timer = time.get_ticks() # 'reset' the timer so the aliens can fire again in .7 seconds

    def calculate_score(self, row):
        scores = {0: 40, # score table by row. all aliens in a row are valued the same amount
                  1: 20, # differs from attempt 1, where the value was assigned by type
                  2: 20,
                  3: 10,
                  4: 10,
                  5: choice([50, 100, 150, 300]) # uses the choice library to get the point value of a ufo
                  }

        score = scores[row]
        self.score += score # increment the total points by the correct amount
        return score

    def create_main_menu(self): # bliting images and premade text to positions found by trial and error. nothing
        self.enemy1 = IMAGES['enemy3_1'] # groundbreaking here unfortunately
        self.enemy1 = transform.scale(self.enemy1, (40, 40))
        self.enemy2 = IMAGES['enemy2_2']
        self.enemy2 = transform.scale(self.enemy2, (40, 40))
        self.enemy3 = IMAGES['enemy1_2']
        self.enemy3 = transform.scale(self.enemy3, (40, 40))
        self.enemy4 = IMAGES['mystery']
        self.enemy4 = transform.scale(self.enemy4, (80, 40))
        self.screen.blit(self.enemy1, (318, 270))
        self.screen.blit(self.enemy2, (318, 320))
        self.screen.blit(self.enemy3, (318, 370))
        self.screen.blit(self.enemy4, (299, 420))

    def check_collisions(self):
        sprite.groupcollide(self.bullets, self.enemyBullets, True, True) # groupcollide takes care of the deletion
            # making the bullet collision a nicely wrapped up package

#groupcollide returns a dictionary of {arg1:arg2}, the .keys will seperate the keys
        for enemy in sprite.groupcollide(self.enemies, self.bullets,
                                         True, True).keys():
            self.sounds['invaderkilled'].play() # play the death sound when an alien is deleted
            self.calculate_score(enemy.row) # find the point value via the row the alien was in
            EnemyExplosion(enemy, self.explosionsGroup) # blit the corrsponding colored explosion sprite at the alien's
            self.gameTimer = time.get_ticks() # reset the timer                             #last position
            # honestly, this is similar to how i did alien explosions in the other schema. it's just compacted this way
            # and i had more practice using groupcollide and passing the key's attributes at this point

        for mystery in sprite.groupcollide(self.mysteryGroup, self.bullets,
                                           True, True).keys(): #you hit that there ufo, bruh?
            mystery.mysteryEntered.stop() # stop the annoying sound
            self.sounds['mysterykilled'].play() # play the reward sound
            score = self.calculate_score(mystery.row) # calculate the choice value using ufo = row 5
            MysteryExplosion(mystery, score, self.explosionsGroup) # blit the explosion sprite where it last was
            newShip = Mystery() # create a new ship, which will begin it's countdown offscreen to randomly emerge again
            self.allSprites.add(newShip) # add the new ship to the needed groups
            self.mysteryGroup.add(newShip)

        for player in sprite.groupcollide(self.playerGroup, self.enemyBullets,
                                          True, True).keys(): # if the player gets hit by a bullet
            if self.life3.alive():
                self.life3.kill() # kill a life unless there are none
            elif self.life2.alive():
                self.life2.kill()
            elif self.life1.alive():
                self.life1.kill()
            else:
                self.gameOver = True # set the flags, the mainloop will do the rest
                self.startGame = False
            self.sounds['shipexplosion'].play() # play the necicary sound
            ShipExplosion(player, self.explosionsGroup) # play the explosion
            self.makeNewShip = True # that one just got deleted, make a new player ship object
            self.shipTimer = time.get_ticks()
            self.shipAlive = False

        if self.enemies.bottom >= 540: # if the enemies reach you, it's game over. they dont go back up, so regardless
            sprite.groupcollide(self.enemies, self.playerGroup, True, True) # of life amount, you lose
            if not self.player.alive() or self.enemies.bottom >= 600: #if the player is dead or the aliens got to you
                self.gameOver = True # set the loss flags
                self.startGame = False

        sprite.groupcollide(self.bullets, self.allBlockers, True, True) # if a blocker is hit with either kind of bullet
        sprite.groupcollide(self.enemyBullets, self.allBlockers, True, True) # delete both objects. gc is handy
        if self.enemies.bottom >= BLOCKERS_POSITION: # if an alien and a blocker collide, delete the alien but not the
            sprite.groupcollide(self.enemies, self.allBlockers, False, True) # blocker. gc makes these two so simple

    def create_new_ship(self, createShip, currentTime): # used in the main loop. makenewship is true if the old one was
        # in a collision. currenttime is just a clone of the timer
        if createShip and (currentTime - self.shipTimer > 900): # if we need a new ship and enough time has passed for
            # the life lost blinking animation to sink in
            self.player = Ship() # make the ship
            self.allSprites.add(self.player) # reference it in the necicary sprite groups
            self.playerGroup.add(self.player)
            self.makeNewShip = False # reset the flags
            self.shipAlive = True

    def create_game_over(self, currentTime): # either the aliens reached you or you got hit with no lives
        self.screen.blit(self.background, (0, 0)) # blit the background ONLY, deleting all the other clutter
        passed = currentTime - self.timer
        if passed < 750:
            self.gameOverText.draw(self.screen)
        elif 750 < passed < 1500: # flash the screen
            self.screen.blit(self.background, (0, 0))
        elif 1500 < passed < 2250: # give the game over some time to sink in, then flash back to the bg
            self.gameOverText.draw(self.screen)
        elif 2250 < passed < 2750: # after a short time, flash the premade game over again
            self.screen.blit(self.background, (0, 0)) # remove it. gives a blinking text effect
        elif passed > 3000: # once time has passed, continue
            self.mainScreen = True # set the flag to know we are in the main screen

        for e in event.get(): # give people the option to ragequit here. dont make me suffer in my pain
            if self.should_exit(e):
                sys.exit()

    def main(self): # main loop of this big honker
        while True:
            if self.mainScreen: # if the main screen flag is true, draw up the main screen
                self.screen.blit(self.background, (0, 0))
                self.titleText.draw(self.screen) # draw the premade text where it needs to be
                self.titleText2.draw(self.screen)
                self.enemy1Text.draw(self.screen)
                self.enemy2Text.draw(self.screen)
                self.enemy3Text.draw(self.screen)
                self.enemy4Text.draw(self.screen)
                self.create_main_menu() # blit the pictures where they should be
                for e in event.get(): # let the user quit if they want to
                    if self.should_exit(e):
                        sys.exit()
                    if e.type == KEYUP: # when any key is pressed, start the game
                        #note, blockers are only created at the start of a new game. they'll stay there between rounds
                        self.allBlockers = sprite.Group(self.make_blockers(0), # make 4 blockers BLOCKERS_POSITION apart
                                                        self.make_blockers(1),
                                                        self.make_blockers(2),
                                                        self.make_blockers(3))
                        self.livesGroup.add(self.life1, self.life2, self.life3) # set up the lives
                        self.reset(0) # init all needed values
                        self.startGame = True # set the flags that the game is going so ms isnt redrawn
                        self.mainScreen = False

            elif self.startGame: # the start game flag is true
                if not self.enemies and not self.explosionsGroup: # there are no enemies made and no explosions happenin
                    currentTime = time.get_ticks() # set the timer
                    if currentTime - self.gameTimer < 3000: # if timer conditions are met
                        self.screen.blit(self.background, (0, 0)) # set the background, wiping away the ms
                        self.scoreText2 = Text(FONT, 20, str(self.score), # set up the score
                                               GREEN, 85, 5)
                        self.scoreText.draw(self.screen) # draw the premade score on the screen
                        self.scoreText2.draw(self.screen) # all these draws are pretty straigtforward.
                        self.nextRoundText.draw(self.screen)
                        self.livesText.draw(self.screen)
                        self.livesGroup.update()
                        self.check_input() # checks to see if the user shot
                    if currentTime - self.gameTimer > 3000:
                        # Move enemies closer to bottom
                        self.enemyPosition += ENEMY_MOVE_DOWN
                        self.reset(self.score)
                        self.gameTimer += 3000
                else: # there are enemies, the game is going
                    currentTime = time.get_ticks()
                    self.play_main_music(currentTime)
                    self.screen.blit(self.background, (0, 0))
                    self.allBlockers.update(self.screen)
                    self.scoreText2 = Text(FONT, 20, str(self.score), GREEN,
                                           85, 5)
                    self.scoreText.draw(self.screen)
                    self.scoreText2.draw(self.screen)
                    self.livesText.draw(self.screen)
                    self.check_input()
                    self.enemies.update(currentTime)
                    self.allSprites.update(self.keys, currentTime)
                    self.explosionsGroup.update(currentTime)
                    self.check_collisions()
                    self.create_new_ship(self.makeNewShip, currentTime)
                    self.make_enemies_shoot()

            elif self.gameOver:
                currentTime = time.get_ticks()
                # Reset enemy starting position
                self.enemyPosition = ENEMY_DEFAULT_POSITION
                self.create_game_over(currentTime)

            display.update()
            self.clock.tick(60)


if __name__ == '__main__':
    game = SpaceInvaders()
    game.main()
